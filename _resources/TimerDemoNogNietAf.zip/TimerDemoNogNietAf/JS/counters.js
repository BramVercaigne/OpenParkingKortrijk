﻿/// <reference path="jquery-2.0.3.min.js" />
/// <reference path="counters.js" />


var demo = (function () {
    return {
        afteller: function () {
            var d1 = new Date();
            d2 = new Date(d1);
            d2.setSeconds(d1.getSeconds() + 10);

            $('#afteller').countdown({
                until: d2, format: 'MS', onExpiry: function () {
                    $('#commentaar').text('Uw minuten zijn afgelopen! Run bitch, run!');
                }
            });

            $("#starttimer").click(function () {
                var t = $("#starttimer").text();
                if (t == "Start timer") {
                    var d3 = new Date();
                    $('#opteller').countdown({ since: d3 });
                    $("#starttimer").text("Stop timer");
                } else {
                    $('#opteller').countdown('pause');
                }
            }
            );
        }
    }
}
)();
demo.afteller();

